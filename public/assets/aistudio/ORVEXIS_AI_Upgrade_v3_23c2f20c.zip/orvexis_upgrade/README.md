# ORVEXIS AI — Upgrade Edition 3.0

A modular AI workspace for chat, coding, learning, documents, visual planning, and creative workflows.

## What's upgraded

- Expanded Tools Studio: app/website blueprints, UI/UX specs, image prompts, video and image-to-video plans, logo/brand concepts, debugging, API design, content/SEO, prompt synthesis, regex, JSON schema, and performance planning.
- Server-side API key handling: keep `GEMINI_API_KEY` on the server; never paste a secret into client-side source code.
- API request validation, JSON body-size limits, baseline security headers, a lightweight per-IP request guard, and safer handling of disconnected streaming clients.
- Existing personalization, themes, response styles, voice, memory, conversation history, and export features retained.
- Responsive React/Vite frontend with a modular component structure.

## Run locally

Requirements: Node.js 20+ (recommended).

1. Extract the ZIP.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and add your Gemini API key.
4. Run `npm run dev`.
5. Open the local URL printed in the terminal.

## Build

- `npm run build` — builds the web app and server bundle.
- `npm run lint` — TypeScript check.
- `npm start` — starts the built server.

## Configure in Google AI Studio

Add `GEMINI_API_KEY` in the project's server-side Secrets panel. Do not commit `.env` or share API keys. The UI can describe and plan image/video generation workflows, but actual media generation requires a connected provider/API and its own credentials; this project does not pretend those services are active by default.

## Important production notes

- The included in-memory request guard is a basic single-process safeguard, not enterprise-grade rate limiting. Use Redis or a gateway-level limiter for multi-instance deployments.
- Configure HTTPS, secure hosting, backups, monitoring, and provider billing limits before public launch.
- Review provider model availability and quotas in your Google AI project. Fallback model names may need adjustment as provider APIs evolve.
- The project does not include user accounts or cloud sync; browser-stored preferences/history remain local to that browser.
